package edu.model.pin;

public class PinOut extends AbstractPin {
	public PinOut(){
		super();
	}
}