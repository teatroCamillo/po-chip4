package edu.model.pin;

public class PinIn extends AbstractPin {
	public PinIn(){
		super();
	}
}
