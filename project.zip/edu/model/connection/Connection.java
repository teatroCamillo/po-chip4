package edu.model.connection;

public record Connection(int sourceChipId, int sourcePinId, int targetChipId, int targetPinId){}
